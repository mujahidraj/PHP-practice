<html>
<head>
    <title>HTML form</title>
</head>
<body>
        <form method="post" action="fileCheck.php" enctype="multipart/form-data">
            Image: <input type="file" name="myfile" value="" /> <br>
                    <input type="submit" name="submit" value="Upload" /> 
        </form>
</body>
</html>