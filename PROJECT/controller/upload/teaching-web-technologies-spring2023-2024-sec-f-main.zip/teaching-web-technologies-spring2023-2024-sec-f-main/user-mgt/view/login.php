<html>
<head>
    <title>HTML form</title>
</head>
<body>
        <form method="post" action="../controller/loginCheck.php" enctype="">
            Username: <input type="text" name="username" value="" /> <br>
            Password: <input type="password" name="password" value="" /> <br>
                      <input type="submit" name="submit" value="Submit" /> 
        </form>
</body>
</html>