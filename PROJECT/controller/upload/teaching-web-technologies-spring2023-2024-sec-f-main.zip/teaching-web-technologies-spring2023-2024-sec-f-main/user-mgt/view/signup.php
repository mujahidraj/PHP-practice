<html>
<head>
    <title>Signup Page</title>
</head>
<body>
        <form method="post" action="../controller/signupCheck.php" enctype="">
            Username: <input type="text" name="username" value="" /> <br>
            Email: <input type="email" name="email" value="" /> <br>
            Password: <input type="password" name="password" value="" /> <br>
                      <input type="submit" name="submit" value="Submit" /> 
        </form>
</body>
</html>